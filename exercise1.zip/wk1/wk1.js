let fName = "Ryan";
let lName = "Lee";
let age = 25;

alert("My name is: " +fName+ " "+lName);
console.log("Name: " +fName+ " " +lName+ " Age: "+age);